/* Cart page rendering and controls. */
(function () {
  'use strict';

  var cart = window.SIDE_A_CART;
  var list = document.getElementById('cart-items');
  if (!cart || !list) return;

  var empty = document.getElementById('cart-empty');
  var layout = document.getElementById('cart-content');
  var clearButton = document.getElementById('clear-cart');

  function node(tag, className, text) {
    var result = document.createElement(tag);
    if (className) result.className = className;
    if (text !== undefined) result.textContent = text;
    return result;
  }

  function artwork(item) {
    if (item.kind === 'catalog' || item.artwork) {
      var image = document.createElement('img');
      image.className = 'cart-thumb';
      image.src = item.kind === 'catalog' ? item.image : item.artwork;
      image.alt = item.artist + ' - ' + item.title + ' artwork';
      image.loading = 'lazy';
      return image;
    }
    return node('div', 'cart-thumb cart-thumb--placeholder', 'SIDE A');
  }

  function makeTracks(tracks) {
    var listNode = node('ol');
    tracks.forEach(function (track) {
      var label = track.title + (track.duration ? ' · ' + track.duration : '');
      listNode.appendChild(node('li', '', label));
    });
    return listNode;
  }

  function renderItem(item) {
    var row = node('article', 'cart-item');
    row.dataset.item = item.id;
    row.appendChild(artwork(item));
    var copy = node('div', 'cart-item-copy');
    copy.appendChild(node('p', 'artist', item.artist));
    copy.appendChild(node('h2', 'cart-item-title', item.title));
    var meta = item.kind === 'catalog'
      ? item.condition + ' condition'
      : item.format + ' · ' + item.color + ' vinyl';
    copy.appendChild(node('p', 'cart-item-meta', meta));

    if (item.kind === 'custom') {
      var specs = node('div', 'cart-item-specs');
      var sides = node('div', 'cart-track-sides');
      [['A', item.sideA], ['B', item.sideB]].forEach(function (side) {
        var block = node('div');
        block.appendChild(node('h4', '', 'Side ' + side[0]));
        block.appendChild(makeTracks(side[1] || []));
        sides.appendChild(block);
      });
      specs.appendChild(node('p', '', 'Custom configuration · price to be confirmed'));
      specs.appendChild(sides);
      copy.appendChild(specs);
    }

    var controls = node('div', 'cart-controls');
    var quantity = node('div', 'quantity-control');
    var decrease = node('button', '', '−');
    decrease.type = 'button';
    decrease.dataset.quantity = '-1';
    decrease.setAttribute('aria-label', 'Decrease quantity of ' + item.title);
    var output = node('output', '', String(item.quantity));
    output.setAttribute('aria-label', 'Quantity');
    var increase = node('button', '', '+');
    increase.type = 'button';
    increase.dataset.quantity = '1';
    increase.setAttribute('aria-label', 'Increase quantity of ' + item.title);
    quantity.append(decrease, output, increase);
    controls.appendChild(quantity);
    if (item.kind === 'custom') {
      var edit = node('a', 'cart-edit', 'Edit');
      edit.href = 'custom-vinyl.html?edit=' + encodeURIComponent(item.id);
      controls.appendChild(edit);
    }
    var remove = node('button', 'cart-remove', 'Remove');
    remove.type = 'button';
    remove.dataset.remove = item.id;
    controls.appendChild(remove);
    copy.appendChild(controls);
    row.appendChild(copy);

    var price = node('div', 'cart-item-price');
    if (item.kind === 'catalog') {
      price.textContent = cart.formatMoney(item.price * item.quantity);
      price.appendChild(node('small', '', cart.formatMoney(item.price) + ' each'));
    } else {
      price.textContent = 'Quote pending';
      price.appendChild(node('small', '', item.quantity + (item.quantity === 1 ? ' copy' : ' copies')));
    }
    row.appendChild(price);
    return row;
  }

  function render() {
    var items = cart.read();
    list.replaceChildren();
    items.forEach(function (item) { list.appendChild(renderItem(item)); });
    var hasItems = items.length > 0;
    empty.hidden = hasItems;
    clearButton.hidden = !hasItems;
    layout.classList.toggle('cart-layout--empty', !hasItems);
    document.getElementById('cart-total-items').textContent = String(cart.itemCount(items));
    var subtotal = cart.catalogSubtotal(items);
    document.getElementById('cart-subtotal').textContent = cart.formatMoney(subtotal);
    document.getElementById('cart-shipping').textContent = 'To be confirmed';
    document.getElementById('cart-grand-total').textContent = items.some(function (item) { return item.kind === 'custom'; }) ? 'Pending quote' : cart.formatMoney(subtotal);
    document.getElementById('cart-summary-note').textContent = items.some(function (item) { return item.kind === 'custom'; })
      ? 'Priced-record subtotal excludes custom concepts. Custom pricing and shipping require confirmation.'
      : 'Estimated total uses a $0.00 shipping placeholder. Final shipping will be confirmed before any order is accepted.';
    var checkout = document.getElementById('checkout-link');
    checkout.classList.toggle('is-disabled', !hasItems);
    if (hasItems) {
      checkout.href = 'purchase.html';
      checkout.removeAttribute('aria-disabled');
      checkout.removeAttribute('tabindex');
    } else {
      checkout.removeAttribute('href');
      checkout.setAttribute('aria-disabled', 'true');
      checkout.tabIndex = -1;
    }
  }

  list.addEventListener('click', function (event) {
    var itemNode = event.target.closest('[data-item]');
    if (!itemNode) return;
    var item = cart.read().find(function (entry) { return entry.id === itemNode.dataset.item; });
    if (!item) return;
    var quantityButton = event.target.closest('[data-quantity]');
    if (quantityButton) {
      var next = item.quantity + Number(quantityButton.dataset.quantity);
      if (next > 0 && next <= cart.maxQuantity) cart.updateQuantity(item.id, next);
      render();
      return;
    }
    var removeButton = event.target.closest('[data-remove]');
    if (removeButton) {
      cart.remove(removeButton.dataset.remove);
      render();
    }
  });

  clearButton.addEventListener('click', function () {
    if (window.confirm('Clear every item from your cart?')) cart.clear();
    render();
  });
  window.addEventListener('sidea:cartchange', render);
  window.addEventListener('storage', function (event) { if (event.key === cart.key) render(); });
  var params = new URLSearchParams(window.location.search);
  if (params.get('updated')) {
    var notice = node('p', 'form-feedback', 'Custom vinyl changes saved.');
    notice.setAttribute('role', 'status');
    list.before(notice);
  }
  render();
}());
