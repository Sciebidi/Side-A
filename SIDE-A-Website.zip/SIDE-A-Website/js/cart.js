/* Shared SIDE A cart storage and catalog helpers. */
(function () {
  'use strict';

  var STORAGE_KEY = 'sideA.cart.v1';
  var MAX_QUANTITY = 99;
  var currency = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' });

  function records() {
    return Array.isArray(window.SIDE_A_RECORDS) ? window.SIDE_A_RECORDS : [];
  }

  function read() {
    try {
      var parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
      if (!Array.isArray(parsed)) return [];
      return parsed.filter(function (item) {
        return item && typeof item.id === 'string' &&
          (item.kind === 'catalog' || item.kind === 'custom') &&
          Number.isSafeInteger(item.quantity) && item.quantity > 0;
      });
    } catch (error) {
      return [];
    }
  }

  function write(items) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
      window.dispatchEvent(new CustomEvent('sidea:cartchange', { detail: { items: items } }));
      return true;
    } catch (error) {
      return false;
    }
  }

  function createId(prefix) {
    var token = window.crypto && typeof window.crypto.randomUUID === 'function'
      ? window.crypto.randomUUID()
      : Date.now().toString(36) + '-' + Math.random().toString(36).slice(2);
    return prefix + '-' + token;
  }

  function findRecord(slug) {
    return records().find(function (record) { return record.slug === slug; }) || null;
  }

  function addCatalog(slug, quantity) {
    var record = findRecord(slug);
    var amount = Number(quantity || 1);
    if (!record || !Number.isSafeInteger(amount) || amount < 1 || amount > MAX_QUANTITY) return false;
    var items = read();
    var item = items.find(function (entry) { return entry.kind === 'catalog' && entry.productId === record.slug; });
    if (item) {
      if (item.quantity + amount > MAX_QUANTITY) return false;
      item.quantity += amount;
    } else {
      items.push({
        id: 'catalog-' + record.slug,
        kind: 'catalog',
        productId: record.slug,
        artist: record.artist,
        title: record.title,
        price: record.price,
        condition: record.condition,
        image: record.image,
        quantity: amount
      });
    }
    return write(items);
  }

  function cleanTracks(tracks) {
    return Array.isArray(tracks) ? tracks.slice(0, 20).map(function (track) {
      return { title: String(track.title || '').trim(), duration: String(track.duration || '').trim() };
    }).filter(function (track) { return track.title; }) : [];
  }

  function cleanCustom(configuration) {
    return {
      title: String(configuration.title || '').trim(),
      artist: String(configuration.artist || '').trim(),
      format: String(configuration.format || ''),
      color: String(configuration.color || ''),
      artwork: String(configuration.artwork || ''),
      sideA: cleanTracks(configuration.sideA),
      sideB: cleanTracks(configuration.sideB)
    };
  }

  function addCustom(configuration, quantity) {
    var amount = Number(quantity || 1);
    var custom = cleanCustom(configuration || {});
    if (!custom.title || !custom.artist || !custom.format || !custom.color ||
        !custom.sideA.length || !custom.sideB.length || !Number.isSafeInteger(amount) ||
        amount < 1 || amount > MAX_QUANTITY) return false;
    var items = read();
    items.push(Object.assign({ id: createId('custom'), kind: 'custom', quantity: amount }, custom));
    return write(items);
  }

  function updateQuantity(id, quantity) {
    var amount = Number(quantity);
    if (!Number.isSafeInteger(amount) || amount < 1 || amount > MAX_QUANTITY) return false;
    var items = read();
    var item = items.find(function (entry) { return entry.id === id; });
    if (!item) return false;
    item.quantity = amount;
    return write(items);
  }

  function updateCustom(id, configuration, quantity) {
    var custom = cleanCustom(configuration || {});
    var amount = Number(quantity);
    if (!custom.title || !custom.artist || !custom.sideA.length || !custom.sideB.length ||
        !Number.isSafeInteger(amount) || amount < 1 || amount > MAX_QUANTITY) return false;
    var items = read();
    var index = items.findIndex(function (entry) { return entry.id === id && entry.kind === 'custom'; });
    if (index < 0) return false;
    items[index] = Object.assign({ id: id, kind: 'custom', quantity: amount }, custom);
    return write(items);
  }

  function remove(id) {
    return write(read().filter(function (item) { return item.id !== id; }));
  }

  function clear() {
    return write([]);
  }

  function itemCount(items) {
    return (items || read()).reduce(function (sum, item) { return sum + item.quantity; }, 0);
  }

  function catalogSubtotal(items) {
    return (items || read()).reduce(function (sum, item) {
      return sum + (item.kind === 'catalog' ? item.price * item.quantity : 0);
    }, 0);
  }

  function formatMoney(amount) {
    return currency.format(amount);
  }

  function mountNavigation() {
    var navigation = document.querySelector('.site-nav');
    if (!navigation) return;
    var inAlbumFolder = /\/albums\//.test(window.location.pathname);
    var prefix = inAlbumFolder ? '../' : '';
    if (!navigation.querySelector('.nav-custom')) {
      var customLink = document.createElement('a');
      customLink.className = 'nav-custom';
      customLink.href = prefix + 'custom-vinyl.html';
      customLink.textContent = 'Custom Vinyl';
      var checkoutLink = navigation.querySelector('.nav-purchase');
      navigation.insertBefore(customLink, checkoutLink || null);
    }
    var cartLink = navigation.querySelector('.nav-cart');
    if (!cartLink) {
      cartLink = document.createElement('a');
      cartLink.className = 'nav-cart';
      cartLink.href = prefix + 'cart.html';
      cartLink.setAttribute('aria-label', 'Cart');
      cartLink.appendChild(document.createTextNode('Cart '));
      var count = document.createElement('span');
      count.className = 'cart-count';
      count.setAttribute('aria-hidden', 'true');
      cartLink.appendChild(count);
      navigation.appendChild(cartLink);
    }
    updateNavigationCount();
  }

  function mountProductActions() {
    if (!records().length) return;
    document.querySelectorAll('.record[data-slug]').forEach(function (recordCard) {
      var actions = recordCard.querySelector('.record-bottom');
      if (!actions || actions.querySelector('[data-cart-add]')) return;
      var button = document.createElement('button');
      button.className = 'record-add';
      button.type = 'button';
      button.dataset.cartAdd = recordCard.dataset.slug;
      button.textContent = 'Add';
      button.setAttribute('aria-label', 'Add ' + recordCard.querySelector('.record-title').textContent.trim() + ' to cart');
      actions.insertBefore(button, actions.querySelector('.detail-button') || null);
    });
  }

  function updateNavigationCount() {
    var count = document.querySelector('.nav-cart .cart-count');
    var link = document.querySelector('.nav-cart');
    if (!count || !link) return;
    var total = itemCount(read());
    count.textContent = String(total);
    link.setAttribute('aria-label', 'Cart, ' + total + (total === 1 ? ' item' : ' items'));
  }

  window.SIDE_A_CART = {
    key: STORAGE_KEY,
    maxQuantity: MAX_QUANTITY,
    read: read,
    findRecord: findRecord,
    addCatalog: addCatalog,
    addCustom: addCustom,
    updateQuantity: updateQuantity,
    updateCustom: updateCustom,
    remove: remove,
    clear: clear,
    itemCount: itemCount,
    catalogSubtotal: catalogSubtotal,
    formatMoney: formatMoney
  };
  mountNavigation();
  mountProductActions();
  document.addEventListener('click', function (event) {
    var button = event.target.closest('[data-cart-add]');
    if (!button) return;
    var added = addCatalog(button.dataset.cartAdd, 1);
    button.textContent = added ? 'Added' : 'Unavailable';
    button.setAttribute('aria-label', added ? 'Added to cart' : 'Unable to add this record to cart');
    window.setTimeout(function () {
      button.textContent = 'Add';
      var title = button.closest('.record').querySelector('.record-title').textContent.trim();
      button.setAttribute('aria-label', 'Add ' + title + ' to cart');
    }, 1800);
  });
  window.addEventListener('sidea:cartchange', updateNavigationCount);
  window.addEventListener('storage', function (event) { if (event.key === STORAGE_KEY) updateNavigationCount(); });
}());
