/* Original SIDE A catalog, preserved as supplied. Shared by carousel, collection, and cart. */
window.SIDE_A_RECORDS = [
  {
    "artist": "The Marías",
    "title": "Cinema",
    "slug": "cinema",
    "year": 2021,
    "genre": "Dream Pop",
    "mood": "Dreamy",
    "condition": "Near Mint",
    "price": 42,
    "image": "cinema.jpg",
    "description": "A perfect album for city lights and a quiet, dreamy evening.",
    "tracks": [
      "Just a Feeling",
      "Calling U Back",
      "Hush",
      "Talk to Her"
    ]
  },
  {
    "artist": "LANY",
    "title": "mama's boy",
    "slug": "mamas-boy",
    "year": 2020,
    "genre": "Indie Pop",
    "mood": "Nostalgic",
    "condition": "Very Good Plus",
    "price": 35,
    "image": "mama's boy.jpg",
    "description": "Nostalgic music about returning to the places that feel like home.",
    "tracks": [
      "you!",
      "cowboy in LA",
      "heart won't let me",
      "if this is the last time"
    ]
  },
  {
    "artist": "Taylor Swift",
    "title": "folklore",
    "slug": "folklore",
    "year": 2020,
    "genre": "Indie Pop",
    "mood": "Melancholic",
    "condition": "Mint",
    "price": 45,
    "image": "folklore.jpg",
    "description": "A heartfelt album with a soft, wistful and slightly melancholic atmosphere.",
    "tracks": [
      "the 1",
      "cardigan",
      "exile",
      "my tears ricochet"
    ]
  },
  {
    "artist": "Taylor Swift",
    "title": "evermore",
    "slug": "evermore",
    "year": 2020,
    "genre": "Indie Pop",
    "mood": "Melancholic",
    "condition": "Mint",
    "price": 45,
    "image": "Evermore.jpg",
    "description": "An album made for quiet moments and enjoying your own company.",
    "tracks": [
      "willow",
      "champagne problems",
      "gold rush",
      "'tis the damn season"
    ]
  },
  {
    "artist": "The Weeknd",
    "title": "After Hours",
    "slug": "after-hours",
    "year": 2020,
    "genre": "R&B",
    "mood": "Late Night",
    "condition": "Mint",
    "price": 50,
    "image": "AfterHours.jpg",
    "description": "Cinematic, dark, and energetic music for the late-night hours.",
    "tracks": [
      "Alone Again",
      "Too Late",
      "Blinding Lights",
      "After Hours"
    ]
  },
  {
    "artist": "Carpenters",
    "title": "Close to You",
    "slug": "close-to-you",
    "year": 1970,
    "genre": "Soft Rock",
    "mood": "Warm",
    "condition": "Very Good",
    "price": 25,
    "image": "closetoyou.jpg",
    "description": "A warm and comforting choice for slow mornings and coffee breaks.",
    "tracks": [
      "We've Only Just Begun",
      "Love Is Surrender",
      "Maybe It's You"
    ]
  },
  {
    "artist": "Ella Fitzgerald",
    "title": "Sings the Duke Ellington Songbook",
    "slug": "duke-ellington-songbook",
    "year": 1957,
    "genre": "Jazz",
    "mood": "Old Souls",
    "condition": "Very Good Plus",
    "price": 60,
    "image": "Sings the Duke Ellington Songbook.jpg",
    "description": "Classic jazz with an elegant, timeless, and soulful feel.",
    "tracks": [
      "Rockin' in Rhythm",
      "Drop Me Off in Harlem",
      "Day Dream",
      "Caravan"
    ]
  },
  {
    "artist": "Luis Miguel",
    "title": "Romance",
    "slug": "romance",
    "year": 1991,
    "genre": "Bolero",
    "mood": "Romantic",
    "condition": "Mint",
    "price": 55,
    "image": "Romance.jpg",
    "description": "A romantic album for relaxed, intimate moments.",
    "tracks": [
      "No Me Platiques Más",
      "Inolvidable",
      "La Puerta",
      "La Barca"
    ]
  },
  {
    "artist": "Panic! At The Disco",
    "title": "selfish machines ptv",
    "slug": "selfish-machines",
    "year": 2009,
    "genre": "Alternative Rock",
    "mood": "Bold",
    "condition": "Good Plus",
    "price": 38,
    "image": "selfish machines ptv.jpeg",
    "description": "A high-energy album for bold, expressive, and loud moments.",
    "tracks": [
      "The Ballad of Mona Lisa",
      "This Is Gospel",
      "Loverboy",
      "Miss Jackson"
    ]
  }
];
