/* Local-only checkout review; no personal data leaves this page. */
(function () {
  'use strict';

  var cart = window.SIDE_A_CART;
  var form = document.getElementById('checkout-form');
  if (!cart || !form) return;

  var requestedAlbum = new URLSearchParams(window.location.search).get('album');
  if (requestedAlbum) {
    if (cart.addCatalog(requestedAlbum, 1)) window.location.replace('cart.html?added=1');
    else window.location.replace('cart.html?unavailable=1');
    return;
  }

  var reviewPanel = document.getElementById('review-panel');
  var feedback = document.getElementById('checkout-feedback');
  var complete = document.getElementById('checkout-complete');
  var submitButton = form.querySelector('button[type="submit"]');
  var currency = cart.formatMoney;

  function node(tag, className, text) {
    var result = document.createElement(tag);
    if (className) result.className = className;
    if (text !== undefined) result.textContent = text;
    return result;
  }

  function makeArtwork(item) {
    if (item.kind === 'catalog' || item.artwork) {
      var image = document.createElement('img');
      image.className = 'cart-thumb';
      image.src = item.kind === 'catalog' ? item.image : item.artwork;
      image.alt = item.title + ' artwork';
      return image;
    }
    return node('div', 'cart-thumb cart-thumb--placeholder', 'SIDE A');
  }

  function appendOrderItem(container, item) {
    var row = node('article', 'checkout-review-item');
    row.appendChild(makeArtwork(item));
    var copy = node('div');
    copy.appendChild(node('strong', '', item.title));
    copy.appendChild(node('p', '', item.artist + ' · ' + item.quantity + (item.quantity === 1 ? ' copy' : ' copies')));
    if (item.kind === 'catalog') {
      copy.appendChild(node('p', '', item.condition + ' · ' + currency(item.price) + ' each'));
    } else {
      copy.appendChild(node('p', '', item.format + ' · ' + item.color + ' · custom price to be confirmed'));
      [['A', item.sideA], ['B', item.sideB]].forEach(function (side) {
        var block = node('div', 'cart-track-sides');
        var list = node('div');
        list.appendChild(node('h4', '', 'Side ' + side[0]));
        var ordered = node('ol');
        (side[1] || []).forEach(function (track) {
          ordered.appendChild(node('li', '', track.title + (track.duration ? ' · ' + track.duration : '')));
        });
        list.appendChild(ordered);
        block.appendChild(list);
        copy.appendChild(block);
      });
    }
    row.appendChild(copy);
    row.appendChild(node('span', 'review-price', item.kind === 'catalog' ? currency(item.price * item.quantity) : 'Quote pending'));
    container.appendChild(row);
  }

  function totals(items) {
    var subtotal = cart.catalogSubtotal(items);
    var hasCustom = items.some(function (item) { return item.kind === 'custom'; });
    return { subtotal: subtotal, hasCustom: hasCustom, total: hasCustom ? 'Pending quote' : currency(subtotal) };
  }

  function renderSummary() {
    var items = cart.read();
    var summary = document.getElementById('checkout-items');
    var amounts = totals(items);
    summary.replaceChildren();
    items.forEach(function (item) { appendOrderItem(summary, item); });
    if (!items.length) summary.appendChild(node('p', 'order-empty', 'Your cart is empty. Add a record before checkout.'));
    document.getElementById('checkout-subtotal').textContent = currency(amounts.subtotal);
    document.getElementById('checkout-total').textContent = amounts.total;
    document.getElementById('checkout-note').textContent = amounts.hasCustom
      ? 'Custom configurations are included for review; their prices and shipping must be confirmed.'
      : 'Shipping is not calculated. Final shipping will be confirmed before any order is accepted.';
    submitButton.disabled = !items.length;
    return items;
  }

  function displayReview() {
    var items = cart.read();
    var amounts = totals(items);
    var reviewItems = document.getElementById('review-items');
    reviewItems.replaceChildren();
    items.forEach(function (item) { appendOrderItem(reviewItems, item); });
    document.getElementById('review-subtotal').textContent = currency(amounts.subtotal);
    document.getElementById('review-total').textContent = amounts.total;
    document.getElementById('review-note').textContent = amounts.hasCustom
      ? 'Custom vinyl pricing and shipping are still pending confirmation; this is not a final payable total.'
      : 'Shipping is a placeholder and will be confirmed before any order is accepted.';
    document.getElementById('review-customer').textContent = [
      document.getElementById('buyer-name').value.trim(),
      document.getElementById('buyer-email').value.trim() + ' · ' + document.getElementById('buyer-phone').value.trim(),
      document.getElementById('shipping-address').value.trim()
    ].join('\n');
    reviewPanel.hidden = false;
    reviewPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
    document.getElementById('confirm-preview').focus({ preventScroll: true });
  }

  form.addEventListener('input', function (event) {
    feedback.hidden = true;
    complete.hidden = true;
    reviewPanel.hidden = true;
    if (event.target.name === 'name' || event.target.name === 'address') {
      event.target.setCustomValidity(event.target.value && !event.target.value.trim() ? 'Please enter more than spaces.' : '');
    }
    if (event.target.name === 'phone' && event.target.value) {
      var digits = event.target.value.replace(/\D/g, '');
      event.target.setCustomValidity(digits.length < 7 ? 'Enter a valid phone number with at least 7 digits.' : '');
    }
  });

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    feedback.hidden = true;
    complete.hidden = true;
    if (!renderSummary().length) {
      feedback.textContent = 'Your cart is empty. Add a record before continuing.';
      feedback.hidden = false;
      feedback.focus();
      return;
    }
    if (!form.reportValidity()) return;
    displayReview();
  });

  document.getElementById('confirm-preview').addEventListener('click', function () {
    if (!cart.read().length) {
      reviewPanel.hidden = true;
      feedback.textContent = 'Your cart is empty. Add a record before continuing.';
      feedback.hidden = false;
      feedback.focus();
      return;
    }
    complete.hidden = false;
    complete.focus();
  });

  window.addEventListener('sidea:cartchange', function () {
    renderSummary();
    reviewPanel.hidden = true;
    complete.hidden = true;
  });
  window.addEventListener('storage', function (event) {
    if (event.key === cart.key) {
      renderSummary();
      reviewPanel.hidden = true;
      complete.hidden = true;
    }
  });
  renderSummary();
}());
