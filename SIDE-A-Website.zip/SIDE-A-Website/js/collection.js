/* Static cards remain browsable without JavaScript. */
(function () {
  'use strict';
  var form = document.querySelector('.collection-toolbar');
  if (!form) return;
  var search = document.getElementById('record-search');
  var genre = document.getElementById('genre-filter');
  var cards = Array.from(document.querySelectorAll('#collection .record'));
  var count = document.querySelector('.result-count');
  var empty = document.querySelector('.empty-state');
  var params = new URLSearchParams(window.location.search);
  function normalized(text) { return text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase(); }
  search.value = params.get('q') || '';
  genre.value = params.get('genre') || '';
  if (genre.selectedIndex < 0) genre.selectedIndex = 0;
  form.hidden = false;
  function filterRecords() {
    var terms = normalized(search.value.trim()).split(/\s+/).filter(Boolean);
    var visible = 0;
    cards.forEach(function (card) {
      var matches = terms.every(function (term) { return normalized(card.dataset.search).includes(term); }) && (!genre.value || card.dataset.genre === genre.value);
      card.hidden = !matches;
      if (matches) visible++;
    });
    count.textContent = visible + (visible === 1 ? ' record' : ' records');
    empty.hidden = visible !== 0;
  }
  search.addEventListener('input', filterRecords);
  genre.addEventListener('change', filterRecords);
  form.addEventListener('submit', function (event) { event.preventDefault(); filterRecords(); });
  document.getElementById('clear-filters').addEventListener('click', function () {
    search.value = '';
    genre.value = '';
    filterRecords();
    search.focus();
  });
  filterRecords();
}());
