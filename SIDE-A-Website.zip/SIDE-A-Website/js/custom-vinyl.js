/* Independent custom vinyl configurations and track editing. */
(function () {
  'use strict';

  var form = document.getElementById('custom-vinyl-form');
  if (!form || !window.SIDE_A_CART) return;

  var list = document.getElementById('vinyl-configurations');
  var feedback = document.getElementById('builder-feedback');
  var editId = new URLSearchParams(window.location.search).get('edit');
  var editing = editId ? window.SIDE_A_CART.read().find(function (item) { return item.id === editId && item.kind === 'custom'; }) : null;
  var configurations = [];
  var capacities = { '7-inch': 2, '10-inch': 4, '12-inch': 8 };

  function newConfiguration(existing) {
    var seed = existing || {};
    return {
      key: 'vinyl-' + Math.random().toString(36).slice(2),
      title: seed.title || '',
      artist: seed.artist || '',
      format: seed.format || '12-inch',
      color: seed.color || 'Black',
      artwork: seed.artwork || '',
      quantity: seed.quantity || 1,
      sideA: seed.sideA ? seed.sideA.map(function (track) { return Object.assign({}, track); }) : [{ title: '', duration: '' }],
      sideB: seed.sideB ? seed.sideB.map(function (track) { return Object.assign({}, track); }) : [{ title: '', duration: '' }]
    };
  }

  function element(tag, className, text) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  function makeInput(labelText, type, value, field, configKey) {
    var wrap = element('div', 'field');
    var id = configKey + '-' + field;
    var label = element('label', '', labelText);
    label.htmlFor = id;
    var input = document.createElement(type === 'select' ? 'select' : 'input');
    input.id = id;
    input.dataset.field = field;
    input.dataset.config = configKey;
    if (type !== 'select') input.type = type;
    if (type === 'select') {
      (field === 'format' ? ['7-inch', '10-inch', '12-inch'] : ['Black', 'Transparent', 'Red', 'Blue', 'Green', 'White']).forEach(function (optionText) {
        var option = element('option', '', optionText);
        option.value = optionText;
        input.appendChild(option);
      });
    }
    if (value !== undefined && type !== 'file') input.value = value;
    input.required = field === 'title' || field === 'artist';
    if (type === 'number') { input.min = '1'; input.max = '99'; input.step = '1'; input.inputMode = 'numeric'; }
    wrap.append(label, input);
    return wrap;
  }

  function trackMarkup(config, side, index, track) {
    var row = element('div', 'track-row');
    row.dataset.trackRow = '';
    row.dataset.config = config.key;
    row.dataset.side = side;
    var titleLabel = element('label', '', 'Track ' + (index + 1));
    var titleInput = document.createElement('input');
    titleInput.type = 'text';
    titleInput.required = true;
    titleInput.maxLength = 100;
    titleInput.placeholder = 'Track title';
    titleInput.value = track.title || '';
    titleInput.dataset.trackField = 'title';
    titleLabel.appendChild(titleInput);
    var durationLabel = element('label', 'duration-field', 'Duration (optional)');
    var durationInput = document.createElement('input');
    durationInput.type = 'text';
    durationInput.inputMode = 'numeric';
    durationInput.placeholder = '3:45';
    durationInput.pattern = '[0-9]{1,3}:[0-5][0-9]';
    durationInput.title = 'Use minutes and seconds, for example 3:45.';
    durationInput.value = track.duration || '';
    durationInput.dataset.trackField = 'duration';
    durationLabel.appendChild(durationInput);
    var tools = element('div', 'track-tools');
    var moveUp = element('button', 'icon-button track-move', '↑');
    moveUp.type = 'button';
    moveUp.dataset.moveTrack = '-1';
    moveUp.disabled = index === 0;
    moveUp.setAttribute('aria-label', 'Move track ' + (index + 1) + ' up on Side ' + side);
    var moveDown = element('button', 'icon-button track-move', '↓');
    moveDown.type = 'button';
    moveDown.dataset.moveTrack = '1';
    moveDown.disabled = index === (config['side' + side].length - 1);
    moveDown.setAttribute('aria-label', 'Move track ' + (index + 1) + ' down on Side ' + side);
    var remove = element('button', 'icon-button track-remove', '×');
    remove.type = 'button';
    remove.dataset.removeTrack = '';
    remove.setAttribute('aria-label', 'Remove track ' + (index + 1) + ' from Side ' + side);
    tools.append(moveUp, moveDown, remove);
    row.append(titleLabel, durationLabel, tools);
    return row;
  }

  function trackSection(config, side) {
    var section = element('fieldset', 'side-editor side-editor--' + side.toLowerCase());
    section.dataset.sideSection = side;
    section.dataset.config = config.key;
    var legend = element('legend', '', 'Side ' + side);
    var help = element('p', 'side-description', side === 'A' ? 'The first side of this record.' : 'The reverse side of this same record.');
    var rows = element('div', 'track-list');
    rows.dataset.trackList = '';
    rows.dataset.config = config.key;
    rows.dataset.side = side;
    config['side' + side].forEach(function (track, index) { rows.appendChild(trackMarkup(config, side, index, track)); });
    var add = element('button', 'text-link add-track', '＋ Add track');
    add.type = 'button';
    add.dataset.addTrack = side;
    add.dataset.config = config.key;
    section.append(legend, help, rows, add);
    return section;
  }

  function renderConfiguration(config, index) {
    var article = element('section', 'vinyl-config');
    article.dataset.configCard = config.key;
    var heading = element('div', 'vinyl-config-heading');
    var titleBox = document.createElement('div');
    titleBox.appendChild(element('p', 'eyebrow', 'Custom pressing concept ' + String(index + 1).padStart(2, '0')));
    titleBox.appendChild(element('h2', '', config.title || 'Untitled vinyl'));
    heading.appendChild(titleBox);
    if (!editing) {
      var removeConfig = element('button', 'text-link config-remove', 'Remove vinyl');
      removeConfig.type = 'button';
      removeConfig.dataset.removeConfig = config.key;
      heading.appendChild(removeConfig);
    }
    var details = element('div', 'custom-details-grid');
    details.append(
      makeInput('Vinyl title', 'text', config.title, 'title', config.key),
      makeInput('Artist name', 'text', config.artist, 'artist', config.key),
      makeInput('Format', 'select', config.format, 'format', config.key),
      makeInput('Vinyl color', 'select', config.color, 'color', config.key),
      makeInput('Copies', 'number', config.quantity, 'quantity', config.key)
    );
    var uploadWrap = element('div', 'field artwork-field');
    var uploadLabel = element('label', '', 'Artwork image (optional)');
    uploadLabel.htmlFor = config.key + '-artwork';
    var upload = document.createElement('input');
    upload.type = 'file';
    upload.accept = 'image/jpeg,image/png,image/webp';
    upload.id = config.key + '-artwork';
    upload.dataset.file = config.key;
    var artPreview = element('div', 'custom-art-preview');
    artPreview.dataset.preview = config.key;
    if (config.artwork) {
      var image = document.createElement('img');
      image.src = config.artwork;
      image.alt = 'Artwork preview for ' + (config.title || 'custom vinyl');
      artPreview.appendChild(image);
    } else {
      artPreview.appendChild(element('span', '', 'Artwork preview'));
    }
    uploadWrap.append(uploadLabel, upload, artPreview);
    details.appendChild(uploadWrap);
    var tracks = element('div', 'side-editors');
    tracks.append(trackSection(config, 'A'), trackSection(config, 'B'));
    article.append(heading, details, tracks);
    return article;
  }

  function render() {
    list.replaceChildren();
    configurations.forEach(function (config, index) { list.appendChild(renderConfiguration(config, index)); });
    document.getElementById('add-vinyl').hidden = Boolean(editing);
    document.getElementById('save-vinyls').textContent = editing ? 'Save changes to cart' : 'Add configurations to cart';
  }

  function configFor(key) {
    return configurations.find(function (config) { return config.key === key; });
  }

  function readTracks(card, side) {
    return Array.from(card.querySelectorAll('[data-track-row][data-side="' + side + '"]')).map(function (row) {
      return {
        title: row.querySelector('[data-track-field="title"]').value.trim(),
        duration: row.querySelector('[data-track-field="duration"]').value.trim()
      };
    });
  }

  function gather(card) {
    var key = card.dataset.configCard;
    var config = configFor(key);
    config.title = card.querySelector('[data-field="title"]').value.trim();
    config.artist = card.querySelector('[data-field="artist"]').value.trim();
    config.format = card.querySelector('[data-field="format"]').value;
    config.color = card.querySelector('[data-field="color"]').value;
    config.quantity = Number(card.querySelector('[data-field="quantity"]').value);
    config.sideA = readTracks(card, 'A');
    config.sideB = readTracks(card, 'B');
    var title = card.querySelector('[data-field="title"]').value.trim();
    card.querySelector('h2').textContent = title || 'Untitled vinyl';
    return config;
  }

  function showFeedback(message, invalid) {
    feedback.textContent = message;
    feedback.hidden = false;
    if (invalid) invalid.focus();
    else feedback.focus();
  }

  function validConfiguration(card) {
    var config = gather(card);
    var requiredFields = Array.from(card.querySelectorAll('[required]'));
    var invalid = requiredFields.find(function (field) { return !field.checkValidity(); });
    if (invalid) {
      invalid.reportValidity();
      return false;
    }
    var duration = Array.from(card.querySelectorAll('[data-track-field="duration"]')).find(function (field) { return field.value && !field.checkValidity(); });
    if (duration) { duration.reportValidity(); return false; }
    if (!Number.isSafeInteger(config.quantity) || config.quantity < 1 || config.quantity > 99) {
      showFeedback('Choose a quantity between 1 and 99 copies.', card.querySelector('[data-field="quantity"]'));
      return false;
    }
    if (!config.sideA.some(function (track) { return track.title; }) || !config.sideB.some(function (track) { return track.title; })) {
      showFeedback('Add at least one titled track to both Side A and Side B.', card.querySelector('[data-track-field="title"]'));
      return false;
    }
    var capacity = capacities[config.format];
    if (config.sideA.filter(function (track) { return track.title; }).length > capacity || config.sideB.filter(function (track) { return track.title; }).length > capacity) {
      showFeedback('The current planning guide allows up to ' + capacity + ' track entries per side for this format.', card.querySelector('[data-field="format"]'));
      return false;
    }
    return true;
  }

  function compressArtwork(file) {
    return new Promise(function (resolve, reject) {
      if (!file || !/^image\/(jpeg|png|webp)$/.test(file.type)) { reject(new Error('Choose a JPEG, PNG, or WebP image.')); return; }
      if (file.size > 12 * 1024 * 1024) { reject(new Error('Artwork files must be 12 MB or smaller.')); return; }
      var objectUrl = URL.createObjectURL(file);
      var image = new Image();
      image.onload = function () {
        var maxSide = 900;
        var scale = Math.min(1, maxSide / Math.max(image.naturalWidth, image.naturalHeight));
        var canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
        canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
        var context = canvas.getContext('2d');
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        URL.revokeObjectURL(objectUrl);
        try { resolve(canvas.toDataURL('image/jpeg', 0.78)); }
        catch (error) { reject(new Error('This image could not be saved for the cart.')); }
      };
      image.onerror = function () { URL.revokeObjectURL(objectUrl); reject(new Error('This image could not be read.')); };
      image.src = objectUrl;
    });
  }

  form.addEventListener('input', function (event) {
    feedback.hidden = true;
    var card = event.target.closest('[data-config-card]');
    if (card) gather(card);
  });

  form.addEventListener('change', function (event) {
    if (!event.target.matches('[data-file]')) return;
    var input = event.target;
    var config = configFor(input.dataset.file);
    if (!input.files || !input.files[0]) return;
    compressArtwork(input.files[0]).then(function (dataUrl) {
      config.artwork = dataUrl;
      var preview = list.querySelector('[data-preview="' + config.key + '"]');
      var image = document.createElement('img');
      image.src = dataUrl;
      image.alt = 'Artwork preview for ' + (config.title || 'custom vinyl');
      preview.replaceChildren(image);
      feedback.hidden = true;
    }).catch(function (error) {
      input.value = '';
      showFeedback(error.message);
    });
  });

  form.addEventListener('click', function (event) {
    var addTrack = event.target.closest('[data-add-track]');
    if (addTrack) {
      var config = configFor(addTrack.dataset.config);
      var side = addTrack.dataset.addTrack;
      var card = addTrack.closest('[data-config-card]');
      var tracks = readTracks(card, side);
      tracks.push({ title: '', duration: '' });
      config['side' + side] = tracks;
      render();
      var newRows = list.querySelectorAll('[data-config-card="' + config.key + '"] [data-side="' + side + '"] [data-track-row]');
      newRows[newRows.length - 1].querySelector('[data-track-field="title"]').focus();
      return;
    }
    var removeTrack = event.target.closest('[data-remove-track]');
    if (removeTrack) {
      var row = removeTrack.closest('[data-track-row]');
      var trackCard = row.closest('[data-config-card]');
      var trackConfig = gather(trackCard);
      trackConfig['side' + row.dataset.side].splice(Array.from(row.parentElement.children).indexOf(row), 1);
      if (!trackConfig['side' + row.dataset.side].length) trackConfig['side' + row.dataset.side].push({ title: '', duration: '' });
      render();
      return;
    }
    var moveTrack = event.target.closest('[data-move-track]');
    if (moveTrack) {
      var moveRow = moveTrack.closest('[data-track-row]');
      var moveCard = moveRow.closest('[data-config-card]');
      var moveConfig = gather(moveCard);
      var sideTracks = moveConfig['side' + moveRow.dataset.side];
      var trackIndex = Array.from(moveRow.parentElement.children).indexOf(moveRow);
      var destination = trackIndex + Number(moveTrack.dataset.moveTrack);
      if (destination >= 0 && destination < sideTracks.length) {
        var current = sideTracks[trackIndex];
        sideTracks[trackIndex] = sideTracks[destination];
        sideTracks[destination] = current;
        render();
        list.querySelector('[data-config-card="' + moveConfig.key + '"] [data-side="' + moveRow.dataset.side + '"] [data-track-row]:nth-child(' + (destination + 1) + ') [data-track-field="title"]').focus();
      }
      return;
    }
    var removeConfig = event.target.closest('[data-remove-config]');
    if (removeConfig) {
      configurations = configurations.filter(function (config) { return config.key !== removeConfig.dataset.removeConfig; });
      if (!configurations.length) configurations.push(newConfiguration());
      render();
    }
  });

  document.getElementById('add-vinyl').addEventListener('click', function () {
    configurations.push(newConfiguration());
    render();
    list.lastElementChild.querySelector('[data-field="title"]').focus();
  });

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    feedback.hidden = true;
    var cards = Array.from(list.querySelectorAll('[data-config-card]'));
    if (!cards.length || !cards.every(validConfiguration)) return;
    var okay = cards.every(function (card) {
      var config = gather(card);
      if (editing) return window.SIDE_A_CART.updateCustom(editing.id, config, config.quantity);
      return window.SIDE_A_CART.addCustom(config, config.quantity);
    });
    if (!okay) {
      showFeedback('The cart could not be saved. Check available browser storage and try again.');
      return;
    }
    if (editing) {
      window.location.href = 'cart.html?updated=1';
      return;
    }
    showFeedback(configurations.length + (configurations.length === 1 ? ' custom vinyl was added' : ' custom vinyls were added') + ' to your cart. Pricing and availability still need confirmation.');
    configurations = [newConfiguration()];
    render();
  });

  if (editing) configurations.push(newConfiguration(editing));
  else configurations.push(newConfiguration());
  render();
}());
