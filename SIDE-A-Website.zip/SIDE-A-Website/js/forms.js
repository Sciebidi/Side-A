/* Local previews only. These forms intentionally do not send or retain personal data. */
(function () {
  'use strict';
  var contact = document.getElementById('contact-form');
  var purchase = document.getElementById('purchase-form');
  document.querySelectorAll('input[type="text"][required], textarea[required]').forEach(function (field) {
    field.addEventListener('input', function () {
      field.setCustomValidity(field.value && !field.value.trim() ? 'Please enter more than spaces.' : '');
    });
  });
  function feedback(element, lines) {
    element.replaceChildren();
    lines.forEach(function (line) {
      var paragraph = document.createElement('p');
      paragraph.textContent = line;
      element.appendChild(paragraph);
    });
    element.hidden = false;
    element.focus();
  }
  if (contact) {
    var contactFeedback = document.getElementById('contact-feedback');
    contact.querySelector('button[type="submit"]').disabled = false;
    contact.addEventListener('input', function () { contactFeedback.hidden = true; });
    contact.addEventListener('submit', function (event) {
      event.preventDefault();
      if (!contact.reportValidity()) return;
      feedback(contactFeedback, [
        'Message preview for ' + document.getElementById('name').value.trim(),
        document.getElementById('message').value.trim(),
        'Your message has not been sent. Email gennaoopss@gmail.com to contact SIDE A. Your entries remain here so you can copy or edit them.'
      ]);
    });
  }
  if (!purchase || !window.SIDE_A_RECORDS) return;
  var records = window.SIDE_A_RECORDS;
  var album = document.getElementById('album');
  var quantity = document.getElementById('quantity');
  var purchaseFeedback = document.getElementById('purchase-feedback');
  var selected = document.getElementById('selected-record');
  var empty = document.getElementById('order-empty');
  var currency = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' });
  var requested = new URLSearchParams(window.location.search).get('album');
  var initial = records.find(function (record) { return record.slug === requested || record.artist + ' - ' + record.title === requested; });
  if (initial) album.value = initial.slug;
  function selection() { return records.find(function (record) { return record.slug === album.value; }); }
  function quantityValue() {
    var value = quantity.valueAsNumber;
    return Number.isSafeInteger(value) && value > 0 ? value : null;
  }
  function renderSummary() {
    var record = selection();
    var amount = quantityValue();
    quantity.setCustomValidity(quantity.value && amount === null ? 'Enter a whole number of 1 or more.' : '');
    purchaseFeedback.hidden = true;
    selected.hidden = !record;
    empty.hidden = Boolean(record);
    if (!record) return;
    var art = document.createElement('span');
    art.className = 'artwork';
    var vinyl = document.createElement('span');
    vinyl.className = 'vinyl';
    vinyl.setAttribute('aria-hidden', 'true');
    var image = document.createElement('img');
    image.className = 'sleeve';
    image.src = record.image;
    image.alt = record.artist + ' — ' + record.title + ' album sleeve';
    image.width = image.height = 600;
    art.append(vinyl, image);
    document.getElementById('summary-art').replaceChildren(art);
    document.getElementById('summary-artist').textContent = record.artist;
    document.getElementById('summary-title').textContent = record.title;
    document.getElementById('summary-meta').textContent = record.year + ' · ' + record.genre + ' · ' + record.condition;
    document.getElementById('summary-price').textContent = currency.format(record.price);
    document.getElementById('summary-quantity').textContent = amount === null ? '—' : amount;
    document.getElementById('summary-subtotal').textContent = amount === null ? '—' : currency.format(record.price * amount);
    document.getElementById('summary-details').href = 'albums/' + record.slug + '.html';
  }
  purchase.querySelector('button[type="submit"]').disabled = false;
  album.addEventListener('change', renderSummary);
  quantity.addEventListener('input', renderSummary);
  purchase.addEventListener('input', function () { purchaseFeedback.hidden = true; });
  purchase.addEventListener('submit', function (event) {
    event.preventDefault();
    if (!purchase.reportValidity()) return;
    var record = selection();
    var amount = quantityValue();
    if (!record || amount === null) return;
    feedback(purchaseFeedback, [
      'Your request preview is ready.',
      amount + ' × ' + record.artist + ' — ' + record.title + ' · Subtotal ' + currency.format(record.price * amount) + '.',
      'No order has been sent and no payment has been taken. Contact gennaoopss@gmail.com to enquire about this record. Your details remain in the form for review.'
    ]);
  });
  renderSummary();
}());
