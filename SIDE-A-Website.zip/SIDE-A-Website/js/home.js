/* A manual carousel: native links, local keyboard controls, and vertical-scroll-safe swipes. */
(function () {
  'use strict';
  var records = window.SIDE_A_RECORDS;
  var carousel = document.querySelector('.album-slider');
  if (!carousel || !records || !records.length) return;
  var index = 0;
  var artLink = document.getElementById('featured-link');
  var image = artLink.querySelector('img');
  var title = document.getElementById('album-name');
  var artist = document.getElementById('album-artist');
  var count = document.getElementById('album-count');
  var details = document.getElementById('featured-details');
  carousel.querySelector('.slider-controls').hidden = false;
  function showAlbum(offset) {
    index = (index + offset + records.length) % records.length;
    var record = records[index];
    var href = 'albums/' + record.slug + '.html';
    image.src = record.image;
    image.alt = record.artist + ' — ' + record.title + ' album sleeve';
    title.textContent = record.title;
    artist.textContent = record.artist + ' / ' + record.year;
    count.textContent = String(index + 1).padStart(2, '0') + ' / ' + String(records.length).padStart(2, '0') + ' — ' + record.mood.toUpperCase();
    artLink.href = title.href = details.href = href;
    artLink.setAttribute('aria-label', 'Explore ' + record.title + ' by ' + record.artist);
  }
  document.getElementById('previous-album').addEventListener('click', function () { showAlbum(-1); });
  document.getElementById('next-album').addEventListener('click', function () { showAlbum(1); });
  carousel.addEventListener('keydown', function (event) {
    if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
      event.preventDefault();
      showAlbum(event.key === 'ArrowLeft' ? -1 : 1);
    }
  });
  var start = null;
  var swiped = false;
  artLink.addEventListener('touchstart', function (event) {
    if (event.touches.length !== 1) { start = null; return; }
    start = { x: event.touches[0].clientX, y: event.touches[0].clientY };
    swiped = false;
  }, { passive: true });
  artLink.addEventListener('touchend', function (event) {
    if (!start) return;
    var dx = event.changedTouches[0].clientX - start.x;
    var dy = event.changedTouches[0].clientY - start.y;
    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.4) {
      showAlbum(dx < 0 ? 1 : -1);
      swiped = true;
    }
    start = null;
  }, { passive: true });
  artLink.addEventListener('touchcancel', function () { start = null; swiped = false; });
  artLink.addEventListener('click', function (event) {
    if (swiped) { event.preventDefault(); swiped = false; }
  });
}());
