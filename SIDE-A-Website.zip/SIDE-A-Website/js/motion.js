/* Progressive navigation enhancement. Links and page content work without JavaScript. */
(function () {
  'use strict';
  var toggle = document.querySelector('.menu-toggle');
  var navigation = document.querySelector('.site-nav');
  if (!toggle || !navigation) return;
  toggle.hidden = false;
  navigation.setAttribute('data-collapsible', '');
  var mobile = window.matchMedia('(max-width: 680px)');
  function setOpen(open) {
    navigation.classList.toggle('is-open', open);
    toggle.setAttribute('aria-expanded', String(open));
    toggle.firstChild.textContent = open ? 'Close ' : 'Menu ';
  }
  toggle.addEventListener('click', function () {
    setOpen(toggle.getAttribute('aria-expanded') !== 'true');
  });
  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && mobile.matches && navigation.classList.contains('is-open')) {
      setOpen(false);
      toggle.focus();
    }
  });
  document.addEventListener('click', function (event) {
    if (mobile.matches && !event.target.closest('.site-header')) setOpen(false);
  });
  mobile.addEventListener('change', function () {
    if (mobile.matches && navigation.contains(document.activeElement)) toggle.focus();
    setOpen(false);
  });
}());
